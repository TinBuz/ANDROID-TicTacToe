package com.example.tinbuzancic.androidtictactoe;

import android.app.Activity;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class main extends Activity {

    private TicTacToeGame mGame;
    private Button mButtons[];
    private Button mNewGame;
    private TextView mInfoTextView;
    private boolean mGameOver = false;



    private char mTurn = TicTacToeGame.HUMAN_PLAYER;
    private static int win;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mNewGame = (Button) findViewById(R.id.NEW_GAME);

        mButtons = new Button[TicTacToeGame.getBOARD_SIZE()];
        mButtons[0] = (Button) findViewById(R.id.square1);
        mButtons[1] = (Button) findViewById(R.id.square2);
        mButtons[2] = (Button) findViewById(R.id.square3);
        mButtons[3] = (Button) findViewById(R.id.square4);
        mButtons[4] = (Button) findViewById(R.id.square5);
        mButtons[5] = (Button) findViewById(R.id.square6);
        mButtons[6] = (Button) findViewById(R.id.square7);
        mButtons[7] = (Button) findViewById(R.id.square8);
        mButtons[8] = (Button) findViewById(R.id.square9);

        mInfoTextView = (TextView) findViewById(R.id.info);

        mGame = new TicTacToeGame();

        startNewGame();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add("New Game");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        startNewGame();
        return true;
    }

    private void startNewGame()
    {
        //clear the grid
        mGame.clearGrid();

        //Reset each button
        for (int i = 0; i < mButtons.length; i++) {
            mButtons[i].setText("");
            mButtons[i].setEnabled(true);
            mButtons[i].setOnClickListener(new ButtonClickListener(i));
        }

        mNewGame.setOnClickListener(new ButtonClickListener(0));

        mTurn = TicTacToeGame.HUMAN_PLAYER;
    }

    public void setMove(char player, int location)
    {
        mGame.setMove(player, location);
        mButtons[location].setEnabled(false);
        mButtons[location].setText(String.valueOf(player));
    }

    /**
     * set starting values, gameOver = false, turn = 1, message = Player X’s turn, game status = “ “
     */
    private void setStartingValues() {
        mGameOver = false;
        mTurn = TicTacToeGame.HUMAN_PLAYER;
        mInfoTextView.setText(R.string.turn_human);
    }

    /**
     * Check for a winner and set gameOver to true if there is a winner or tie
     */
    public void checkForGameOver() {
        if(win == 0 || win == 1 || win == 2) {
            mGameOver = true;
        }
    }

    // Handles clicks on the game board buttons
    private class ButtonClickListener implements View.OnClickListener {
        int location;
        public ButtonClickListener(int location) {
            this.location = location;
        }
        public void onClick(View view) {
            if(!mGameOver)
            {
                if(mButtons[location].isEnabled())
                {
                    setMove(TicTacToeGame.HUMAN_PLAYER, location);
                    int winner = mGame.checkForWinner();
                    if(winner == 0)
                    {
                        mInfoTextView.setText(R.string.turn_computer);
                        int move = mGame.getComputerMove();
                        setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                        winner = mGame.checkForWinner();
                    }
                    if(winner == 0)
                    {
                        mInfoTextView.setText(R.string.turn_human);
                    }
                    else if(winner == 1)
                    {
                        mInfoTextView.setText(R.string.result_tie);
                        mGameOver = true;
                    }
                    else if (winner == 2)
                    {
                        mInfoTextView.setText(R.string.result_human_wins);
                        mGameOver = true;
                    }
                    else
                    {
                        mInfoTextView.setText(R.string.result_computer_wins);
                        mGameOver = true;
                    }
                }
            }
            if(mNewGame.isPressed())
            {
                checkForGameOver();
                setStartingValues();
                startNewGame();
            }
        }
    }
}
